#/bin/bash

echo "Cloning Cairo Simulator..."
git clone https://github.com/cairo-robotics/cairo_simulator.git




